DROP DATABASE IF EXISTS social_network;
CREATE DATABASE social_network CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
use social_network;

create table user(
id int not null primary key auto_increment,
firstname varchar(50) not null,
lastname varchar(50) not null,
email varchar(100) not null,
pass char(60) not null,
image LONGBLOB,
role varchar(10)
)engine=InnoDB;

create unique index ix1 on user(email);


create table post(
id int not null primary key auto_increment,
content text,
user int not null,
date datetime not null default now()
)engine=InnoDB;

create table comment(
id int not null primary key auto_increment,
user int not null,
post int not null,
content text not null,
date datetime not null default now()
)engine=InnoDB;

create table likes(
id int not null primary key auto_increment,
user int not null,
post int not null,
content varchar(10) not null,
uniqueinsert varchar(10) not null
)engine=InnoDB;
create unique index unique_insert on likes(uniqueinsert);



create table tag(
id int not null primary key auto_increment,
content text not null
)engine=InnoDB;

create table tag_post(
post int not null,
tag int not null
)engine=InnoDB;

create table report(
post int not null,
user int not null,
content varchar(255) not null,
uniqueinsert1 varchar(20) not null
)engine=InnoDB;
create unique index uniqueinsert123 on report(uniqueinsert1);



alter table post add FOREIGN KEY (user) REFERENCES user(id);

alter table comment add FOREIGN KEY (user) REFERENCES user(id);
alter table comment add FOREIGN KEY (post) REFERENCES post(id);

alter table likes add FOREIGN KEY (user) REFERENCES user(id);
alter table likes add FOREIGN KEY (post) REFERENCES post(id);

alter table tag_post add FOREIGN KEY (post) REFERENCES post(id);
alter table tag_post add FOREIGN KEY(tag) references tag(id);

alter table report add FOREIGN KEY (post) REFERENCES post(id);
alter table report add FOREIGN KEY (user) REFERENCES user(id);






