<?php

class IndexController
{
    public function index()
    {
        $view = new View();
        $posts = Post::all();

        $view->render('index', [
            "posts" => $posts,
            "message" => ""
        ]);
    }

    public function updateUser($id = 0)
    {
        $view = new View();

        $view->render('updateUser', [
            "post" => Post::find($id),
            "message" => ""
        ]);

    }

    public function view($id = 0)
    {
        $view = new View();

        $view->render('view', [
            "post" => Post::find($id)
        ]);
    }


    public function newPost()
    {

            $connection = Db::connect();
            $sql = 'INSERT INTO post (content,user) VALUES (:content,:user)';
            $stmt = $connection->prepare($sql);
            $stmt->bindValue('content', Request::post("text"));
            $stmt->bindValue('user', Session::getInstance()->getUser()->id);
            $stmt->execute();
            header('Location: ' . App::config('url'));


    }

    public function newTag($id)
    {
        $data = $this->_validate($_POST);

        if ($data === false) {
            header('Location: ' . App::config('url'));
        } else {
            $db = Db::connect();
            $db->beginTransaction();
            $stmt = $db->prepare("INSERT INTO tag (content) VALUES (:content)");
            $stmt->bindValue('cont', $data['cont']);
            $stmt->execute();
            $tag_id=$db->lastInsertId();

            $stmt = $db->prepare("INSERT INTO tag_post (post,tag) VALUES (:post, :tag)");
            $stmt->bindValue('post', $id);
            $stmt->bindValue('tag', $tag_id);
            $stmt->execute();
            $db->commit();

            header('Location: ' . App::config('url'));
        }
    }




    /**
     * @param $data
     * @return array|bool
     */
    private function _validate($data)
    {
        $required = ['content'];

        //validate required keys
        foreach ($required as $key) {
            if (!isset($data[$key])) {
                return false;
            }

            $data[$key] = trim((string)$data[$key]);
            if (empty($data[$key])) {
                return false;
            }
        }
        return $data;
    }



}