<?php
class Post
{
    private $id;
    private $content;
    private $user;
    private $date;
    private $likes;
    private $comments;
    private $userid;
    private $tag;
    private $dislikes;
    private $report;

    public function __construct($id, $content, $user,$date, $likes,$comments,$userid,$tag,$dislikes,$report)
    {
        $this->setId($id);
        $this->setContent($content);
        $this->setUser($user);
        $this->setDate($date);
        $this->setLikes($likes);
        $this->setComments($comments);
        $this->setUserid($userid);
        $this->setTag($tag);
        $this->setDislikes($dislikes);
        $this->setReport($report);
    }
    public function __set($name, $value)
    {
        $this->$name = $value;
    }
    public function __get($name)
    {
        return isset($this->$name) ? $this->$name : null;
    }
    public function __call($name, $arguments)
    {
        $function = substr($name, 0, 3);
        if ($function === 'set') {
            $this->__set(strtolower(substr($name, 3)), $arguments[0]);
            return $this;
        } else if ($function === 'get') {
            return $this->__get(strtolower(substr($name, 3)));
        }
        return $this;
    }
    public static function allXXXXXX()
    {
        // $time=microtime(true);
        $list = [];
        $db = Db::connect();
        $statement = $db->prepare("select 
        a.id, a.content, concat(b.firstname, ' ', b.lastname) as user, a.date, 
        count(c.id) as likes
        from 
        post a inner join user b on a.user=b.id 
        left join likes c on a.id=c.post 
        
        where a.date > ADDDATE(now(), INTERVAL -7 DAY) 
        group by a.id, a.content, concat(b.firstname, ' ', b.lastname), a.date 
        order by a.date desc limit 10");
        $statement->execute();
        foreach ($statement->fetchAll() as $post) {
            $statement = $db->prepare("select a.id, a.content, concat(b.firstname, ' ', b.lastname) as user, a.date from comment a inner join user b on a.user=b.id where a.post=:id ");
            $statement->bindValue('id', $post->id);
            $statement->execute();
            $comments = $statement->fetchAll();
            $statement = $db->prepare("
                    select a.content
                    from tag a
                    inner join tag_post b on a.id = b.tag
                    inner join post p on b.post = p.id
                    where b.post = :id");
            $statement->bindValue('id', $post->id);
            $statement->execute();
            $tag = $statement->fetchAll();

            $statement = $db->prepare("select count(post) from report where post = :id");
            $statement->bindValue('id', $post->id);
            $statement->execute();
            $report = $statement->fetchAll();
            $list[] = new Post($post->id, $post->content, $post->user,$post->date,$post->likes,$comments,0,$tag,$post->dislike,$report);
            // $list[] = $post;
        }
        //   $time2 = microtime(true);
        // echo $time2-$time;
        return $list;
    }
    public static function all()
    {
        //  $time=microtime(true);
        $list = [];
        $db = Db::connect();
        $statement = $db->prepare("select
  a.id, a.content, concat(b.firstname, ' ', b.lastname) as user, a.date,
  d.id as commentid, d.content as commentcontent ,
  concat(e.firstname, ' ', e.lastname) as commentuser, r.post as reportPostId,
  r.user as reportUserid,
  d.date as commentdate, t.content as contentTag,
  count(IF(c.content = 'like', 1, NULL)) as likes,
  count(IF(c.content = 'dislike', 1, NULL)) as dislikes
from
  post a inner join user b on a.user=b.id
         left join likes c on a.id=c.post
         left join comment d on a.id=d.post
         left join user e on d.user=e.id
         left join tag_post tp on a.id = tp.post
         left join tag t on tp.tag = t.id
         left  join report r on a.id = r.post
where a.date > ADDDATE(now(), INTERVAL -7 DAY)
group by a.id, a.content, concat(b.firstname, ' ', b.lastname), a.date ,
         d.id , d.content  ,
         concat(e.firstname, ' ', e.lastname) ,d.date,t.content, r.post, r.user
order by a.date desc limit 100");
        $statement->execute();
        //todo završiti
        $komentari=[];
        $tagovi = [];
        $reportovi = [];
        $postid=0;
        foreach ($statement->fetchAll() as $post) {
            if($post->commentid==null){
                $list[] = new Post($post->id, $post->content, $post->user,$post->date,$post->likes,[] ,0,[],$post->dislikes, []);
                continue;
            }
            if($postid===0 || $postid!==$post->id){
                if($postid!==0){
                    $p->setComments($komentari);
                    $list[]=$p;
                    $u->setTag($tagovi);
                    $list[]=$u;
                    $t->setReport($reportovi);
                    $list[]=$u;
                }
                $postid=$post->id;
                $p = new Post($post->id, $post->content, $post->user,$post->date,$post->likes,[] ,0,[],$post->dislikes,[]);
                $komentari=[];
                $tagovi = [];
                $reportovi = [];
            }
            $k=new stdClass();
            $k->id = $post->commentid;
            $k->content = $post->commentcontent;
            $k->user = $post->commentuser;
            $k->date = $post->commentdate;
            $komentari[] = $k;
            $n=new stdClass();
            $n->content = $post->contentTag;
            $tagovi[] = $n;
            $f=new stdClass();
            $f->content = $post->contentReport;
            $tagovi[] = $f;
        }
        //$time2 = microtime(true);
        //echo $time2-$time;
        return $list;
    }
    public static function find($id)
    {
        $id = intval($id);
        $db = Db::connect();
        $statement = $db->prepare("select 
        a.id, a.content, concat(b.firstname, ' ', b.lastname) as user, a.date, 
        a.user as userid,
        count(IF(c.content = 'like', 1, NULL)) as likes,
        count(IF(c.content = 'dislike', 1, NULL)) as dislikes
        from 
        post a inner join user b on a.user=b.id 
        left join likes c on a.id=c.post 
         where a.id=:id");
        $statement->bindValue('id', $id);
        $statement->execute();
        $post = $statement->fetch();
        $statement = $db->prepare("select a.id, a.content, concat(b.firstname, ' ', b.lastname) as user, a.date from comment a inner join user b on a.user=b.id where a.post=:id ");
        $statement->bindValue('id', $id);
        $statement->execute();
        $comments = $statement->fetchAll();
        $statement = $db->prepare("
                    select a.content
                    from tag a
                    inner join tag_post b on a.id = b.tag
                    inner join post p on b.post = p.id
                    where b.post = :id");
        $statement->bindValue('id', $id);
        $statement->execute();
        $tag = $statement->fetchAll();
        $statement = $db->prepare("select a.content
from report a
       inner join post p on a.post = p.id
where p.id = :id;");
        $statement->bindValue('id', $post->id);
        $statement->execute();
        $report = $statement->fetchAll();
        return new Post($post->id, $post->content, $post->user, $post->date,$post->likes, $comments,$post->userid,$tag,$post->dislikes,$report);
    }
}