<?php

return [
    'url' => 'http://localhost/InchooPHPAkademijaZ7/',
    'mode'  => 'development',
    "db"=>[
        "host"=>"localhost",
        "name"=>"social_network",
        "user"=>"root",
        "password"=>"kruno031031"
    ]
];